-- Migration: Add is_verified column to users table (if not already present)
-- Run this once on your database

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `is_verified` TINYINT(1) NOT NULL DEFAULT 0 AFTER `gov_id_url`;

-- Migration: Add middle_initial column to users table
-- Run this once on your database

ALTER TABLE `users`
  ADD COLUMN `middle_initial` varchar(5) DEFAULT '' AFTER `first_name`;

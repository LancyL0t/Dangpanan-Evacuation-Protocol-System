-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 25, 2026 at 10:02 AM
-- Server version: 11.8.5-MariaDB-log
-- PHP Version: 8.4.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dangpananevac_dangpanan_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `alert_id` int(11) NOT NULL,
  `type` enum('critical','warning','info') NOT NULL DEFAULT 'info',
  `title` varchar(200) NOT NULL,
  `body` text NOT NULL,
  `source` varchar(100) DEFAULT NULL,
  `affected_area` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`alert_id`, `type`, `title`, `body`, `source`, `affected_area`, `is_active`, `created_at`) VALUES
(1, 'critical', 'Typhoon Warning – Signal No. 3', 'Typhoon Paeng is expected to make landfall within 18 hours. Residents in low-lying and flood-prone areas are strongly advised to evacuate immediately to the nearest evacuation center. Do not wait until the storm arrives.', 'PAGASA', 'Tangub, Banago, Mandalagan, Singcang', 1, '2026-02-18 10:55:19'),
(2, 'warning', 'Flash Flood Advisory', 'Heavy continuous rainfall has been recorded upstream. Flash flooding is possible in riverside communities. Residents along the Lacson Street corridor and Barangay Handumanan are advised to be on alert.', 'MDRRMO Bacolod', 'Handumanan, Lacson, Barangay 40', 1, '2026-02-18 10:55:19'),
(3, 'info', '15 Evacuation Centers Now Open', 'As of today, 15 evacuation centers across Bacolod City are now open and accepting evacuees. These include BAYS Center, USLS Coliseum, Panaad Stadium, and city schools. Bring your go-bag, medications, and important documents.', 'Bacolod City Government', 'City-Wide', 1, '2026-02-18 10:55:19');

-- --------------------------------------------------------

--
-- Table structure for table `identity_verification`
--

CREATE TABLE `identity_verification` (
  `verification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `submitted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `occupants`
--

CREATE TABLE `occupants` (
  `occupant_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shelter_id` int(11) NOT NULL,
  `group_size` int(11) NOT NULL DEFAULT 1,
  `approval_code` varchar(12) NOT NULL,
  `checked_in_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `checked_out_at` timestamp NULL DEFAULT NULL,
  `status` enum('active','checked_out','removed') DEFAULT 'active',
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `occupants`
--

INSERT INTO `occupants` (`occupant_id`, `request_id`, `user_id`, `shelter_id`, `group_size`, `approval_code`, `checked_in_at`, `checked_out_at`, `status`, `notes`) VALUES
(9, 25, 2, 8, 1, '375509', '2026-02-18 06:11:27', '2026-02-18 06:12:50', 'checked_out', ''),
(10, 27, 9, 6, 1, '786721', '2026-02-19 02:08:59', '2026-02-19 02:09:32', 'checked_out', '');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `shelter_id` int(11) NOT NULL,
  `group_size` int(11) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `status` enum('pending','approved','declined','checked_in','completed') DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `approval_code` varchar(12) DEFAULT NULL,
  `is_notified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `user_id`, `shelter_id`, `group_size`, `notes`, `status`, `rejection_reason`, `approval_code`, `is_notified`, `created_at`, `reviewed_at`, `approved_at`) VALUES
(25, 2, 8, 1, '', 'completed', NULL, '375509', 1, '2026-02-18 06:08:44', NULL, '2026-02-18 06:09:00'),
(27, 9, 6, 1, '', 'completed', NULL, '786721', 1, '2026-02-19 02:08:04', NULL, '2026-02-19 02:08:19'),
(28, 9, 12, 1, '', 'pending', NULL, NULL, 0, '2026-02-19 09:30:43', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shelter`
--

CREATE TABLE `shelter` (
  `shelter_id` int(11) NOT NULL,
  `shelter_name` varchar(100) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `current_capacity` int(11) DEFAULT 0,
  `max_capacity` int(11) NOT NULL,
  `amenities` text DEFAULT NULL,
  `supplies` text DEFAULT NULL,
  `distance` float DEFAULT NULL,
  `is_full` tinyint(1) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `host_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shelter`
--

INSERT INTO `shelter` (`shelter_id`, `shelter_name`, `location`, `latitude`, `longitude`, `contact_number`, `type`, `current_capacity`, `max_capacity`, `amenities`, `supplies`, `distance`, `is_full`, `is_active`, `host_id`) VALUES
(5, 'Jamon Residence', '8 Dimasalang Street, Tangub, Bacolod City, Negros Occidental', 10.63377900, 122.93392300, '09123456787', NULL, 3, 10, '[\"Food\",\"Medical\",\"WiFi\",\"Laundry\",\"Shower\",\"Beds\"]', '{\"water\":{\"qty\":3,\"unit\":\"Gal\"},\"food\":{\"qty\":2,\"unit\":\"Packs\"},\"medical\":{\"qty\":3,\"unit\":\"Items\"},\"bedding\":{\"qty\":2,\"unit\":\"Sets\"}}', NULL, 0, 1, 1),
(6, 'Lance House', '8 Dimasalang Street, Tangub, Bacolod City, Negros Occidental', NULL, NULL, '09213456781', NULL, 5, 7, '[]', '{\"water\":{\"qty\":10,\"unit\":\"Gal\"},\"food\":{\"qty\":23,\"unit\":\"Packs\"},\"medical\":{\"qty\":100,\"unit\":\"Sets\"},\"bedding\":{\"qty\":0,\"unit\":\"Sets\"}}', NULL, 0, 0, 2),
(8, 'Jason House', 't4ert, 45342, Baclod, tret', 10.64491300, 122.93622000, '43642364374', NULL, 2, 10, '', '{\"water\":{\"qty\":\"65\",\"unit\":\"Gallons\"},\"food\":{\"qty\":\"5\",\"unit\":\"Packs\"},\"medical\":{\"qty\":\"6\",\"unit\":\"Kits\"}}', NULL, 0, 1, 6),
(9, 'BAYS Center Evacuation Zone', 'San Juan St, Bacolod, 6100 Negros Occidental', 10.66980000, 122.94390000, '09171234567', 'Gymnasium', 0, 500, '[\"Sleeping Mats\",\"Comfort Rooms\",\"Medical Station\",\"Charging Station\"]', '{\"water\":{\"qty\":500,\"unit\":\"Gallons\"},\"food\":{\"qty\":1000,\"unit\":\"Packs\"},\"medical\":{\"qty\":100,\"unit\":\"Kits\"}}', NULL, 0, 1, NULL),
(10, 'NOMPAC Shelter', 'Aguinaldo Street, Bacolod City', 10.67350000, 122.94600000, '09187654321', 'Government Center', 0, 300, '[\"WiFi\",\"Air Ventilation\",\"Food Station\"]', '{\"water\":{\"qty\":200,\"unit\":\"Gallons\"},\"food\":{\"qty\":500,\"unit\":\"Packs\"},\"medical\":{\"qty\":50,\"unit\":\"Kits\"}}', NULL, 0, 1, NULL),
(11, 'Bacolod City College Hall', 'Taculing, Bacolod City', 10.65170000, 122.94750000, '09223334444', 'School', 0, 150, '[\"Classrooms\",\"Clinic\",\"Water Station\"]', '{\"water\":{\"qty\":100,\"unit\":\"Gallons\"},\"food\":{\"qty\":300,\"unit\":\"Packs\"},\"medical\":{\"qty\":20,\"unit\":\"Kits\"}}', NULL, 0, 1, NULL),
(12, 'USLS Coliseum Safe Zone', 'La Salle Avenue, Bacolod City', 10.68050000, 122.96100000, '09998887777', 'Gymnasium', 0, 1000, '[\"Shower Rooms\",\"Generator\",\"Wi-Fi\",\"Isolation Area\"]', '{\"water\":{\"qty\":1000,\"unit\":\"Gallons\"},\"food\":{\"qty\":2000,\"unit\":\"Packs\"},\"medical\":{\"qty\":200,\"unit\":\"Kits\"}}', NULL, 0, 1, NULL),
(13, 'Panaad Park & Stadium', 'Barangay Mansilingan, Bacolod City', 10.63600000, 122.97300000, '09155556666', 'Sports Complex', 0, 2000, '[\"Open Field\",\"Grandstand\",\"Medical Center\",\"Police Outpost\"]', '{\"water\":{\"qty\":2000,\"unit\":\"Gallons\"},\"food\":{\"qty\":5000,\"unit\":\"Packs\"},\"medical\":{\"qty\":500,\"unit\":\"Kits\"}}', NULL, 0, 1, NULL),
(14, 'JADE COURT', '1234, Alijis, BACOLOD, Negros Occidental', 10.64500800, 122.94057500, '3626326', NULL, 0, 124, '', '{\"water\":{\"qty\":\"100\",\"unit\":\"Gallons\"},\"food\":{\"qty\":\"10\",\"unit\":\"Packs\"},\"medical\":{\"qty\":\"10\",\"unit\":\"Kits\"}}', NULL, 0, 0, 5),
(15, 'Stacy\'s schitzhu dogpark', 'East Homes3, Estefania, Bacolod City, Negross Occidental ', 10.66960400, 122.99638500, '09123456788', NULL, 0, 10, '[\"Food\",\"Medical\",\"WiFi\",\"Laundry\",\"Shower\",\"Beds\"]', '{\"water\":{\"qty\":\"3\",\"unit\":\"Gallons\"},\"food\":{\"qty\":\"10\",\"unit\":\"Packs\"},\"medical\":{\"qty\":\"5\",\"unit\":\"Kits\"}}', NULL, 0, 1, 10),
(21, 'Villarosa Family Bungalow', 'Lot 15, Ph 1, Dona Juliana Subdivision, Bacolod City', 10.65800000, 122.95500000, '09174445566', 'Private House', 0, 6, '[\"Kitchen\", \"Extra Mats\", \"First Aid Kit\"]', '{\"water\":{\"qty\":10,\"unit\":\"Gallons\"},\"food\":{\"qty\":15,\"unit\":\"Packs\"},\"medical\":{\"qty\":5,\"unit\":\"Kits\"}}', NULL, 0, 1, 1),
(22, 'Sia Studio Apartment', '12-B Lacson Street, near Robinsons Place, Bacolod City', 10.68200000, 122.95300000, '09223334411', 'Apartment', 0, 4, '[\"WiFi\", \"Generator\", \"Aircon\"]', '{\"water\":{\"qty\":5,\"unit\":\"Gallons\"},\"food\":{\"qty\":10,\"unit\":\"Packs\"},\"medical\":{\"qty\":2,\"unit\":\"Kits\"}}', NULL, 0, 1, 6),
(23, 'Alvarez Compound (Back House)', 'Purok 4, Brgy. Alijis, Bacolod City (Behind the Sari-sari store)', 10.64200000, 122.94300000, '09156667788', 'Private House', 0, 10, '[\"Spacious Backyard\", \"Laundry Area\", \"Water Pump\"]', '{\"water\":{\"qty\":25,\"unit\":\"Gallons\"},\"food\":{\"qty\":30,\"unit\":\"Packs\"},\"medical\":{\"qty\":10,\"unit\":\"Kits\"}}', NULL, 0, 1, 10),
(24, 'Gomez Apartment Units', 'Burgos-Extension, Brgy. Villamonte, Bacolod City', 10.67500000, 122.96200000, '09985554433', 'Apartment', 0, 12, '[\"Fire Exit\", \"CCTV\", \"Drinking Water\"]', '{\"water\":{\"qty\":15,\"unit\":\"Gallons\"},\"food\":{\"qty\":25,\"unit\":\"Packs\"},\"medical\":{\"qty\":5,\"unit\":\"Kits\"}}', NULL, 0, 1, NULL),
(25, 'Ledesma Residence', 'Brgy. Mandalagan, near Art District, Bacolod City', 10.69300000, 122.95900000, '09127778899', 'Private House', 0, 8, '[\"Beds\", \"Shower\", \"Safe for Pets\"]', '{\"water\":{\"qty\":12,\"unit\":\"Gallons\"},\"food\":{\"qty\":20,\"unit\":\"Packs\"},\"medical\":{\"qty\":6,\"unit\":\"Kits\"}}', NULL, 0, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `system_logs`
--

CREATE TABLE `system_logs` (
  `log_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_initial` varchar(5) DEFAULT '',
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `gov_id_url` varchar(255) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `role` enum('Citizen','Host','Admin') DEFAULT 'Citizen',
  `host_status` enum('none','active_host','relinquished') DEFAULT 'none',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `middle_initial`, `last_name`, `email`, `password_hash`, `phone_number`, `gov_id_url`, `is_verified`, `role`, `host_status`, `created_at`) VALUES
(1, 'Lance Jason', '', 'Jamon', 'jamon@gmail.com', '$2y$10$r5c16UdBY/d3R3o6fOBcYO/T2VEAOG5r.e6HAeMGvBy1BK1fi5tiC', '09214463284', 'uploads/id.png', 0, 'Citizen', 'active_host', '2026-01-29 13:05:17'),
(2, 'Lance', '', '', 'jamon.lancejason@gmail.com', '$2y$10$uTdZrKpkwejf4dUPj4wbmu.U2xez9DBDgTcSL6zYX1h6LD6ow02g.', '09214463284', 'uploads/id.png', 0, 'Host', 'relinquished', '2026-02-08 16:33:42'),
(3, 'System', '', 'Administrator', 'admin@dangpanan.com', '$2y$10$r5c16UdBY/d3R3o6fOBcYO/T2VEAOG5r.e6HAeMGvBy1BK1fi5tiC', '+63 917 123 456', 'uploads/id.png', 0, 'Admin', 'none', '2026-02-09 03:11:30'),
(4, 'Admin', '', '', 'dangpananAdmin@gmail.com', '$2y$10$0VnsdeIlPue12W6niTS2deK0aA9HXrp0VP5ZoZeH13bTVYncaNHTW', '092134567', 'uploads/id.png', 0, 'Admin', 'none', '2026-02-09 03:38:55'),
(5, 'Reina Cassopeia Say', '', '', 'say@gmail.com', '$2y$10$tJf7bMmYD7CkJOUgK2VTseIIPUvK2.oYY6XXtY5W0QxE5NufYvJQG', '0912345678', 'uploads/id.png', 0, 'Citizen', 'relinquished', '2026-02-10 09:54:54'),
(6, 'Jason Jamon', '', '', 'rwrer@gmail.com', '$2y$10$REzp1XTB91LYJBb17hBpWOPUhbUOgj70p6AzzBuSGIx9JV4LvTpgO', '09123456788', 'uploads/id.png', 0, 'Citizen', 'active_host', '2026-02-10 12:39:07'),
(9, 'User', '', '', 'user@dangpanan.com', '$2y$12$0B4Zk7UAC5om7SXg63C2tu5kpq.pcNg/ak3VB9Zq6ZB.0NK0dO5u.', '09214463284', 'uploads/id.png', 1, 'Citizen', 'none', '2026-02-11 11:53:22'),
(10, 'Stacy corpus', '', '', 'stacycorps@gmail.com', '$2y$12$ih9lMzZiSZ9/esmsjxkmDe0fvmCBMvKtMCjTBxW7F8bhtMqpDlbeK', '09123456788', 'uploads/id.png', 0, 'Citizen', 'active_host', '2026-02-13 06:54:11'),
(11, 'Kurisu Tokyoto', '', '', 'tokyotokurisu@gmail.com', '$2y$12$yzVRCC6U.PcGRlI.wH2PWOUYyjGssQo1GHFygGYtkSulAZZvV5DXW', '09938028756', 'uploads/id.png', 0, 'Citizen', 'none', '2026-02-13 13:04:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`alert_id`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `identity_verification`
--
ALTER TABLE `identity_verification`
  ADD PRIMARY KEY (`verification_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `occupants`
--
ALTER TABLE `occupants`
  ADD PRIMARY KEY (`occupant_id`),
  ADD KEY `idx_request_id` (`request_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_shelter_id` (`shelter_id`),
  ADD KEY `idx_approval_code` (`approval_code`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_approval_code` (`approval_code`),
  ADD KEY `idx_status_shelter` (`status`,`shelter_id`);

--
-- Indexes for table `shelter`
--
ALTER TABLE `shelter`
  ADD PRIMARY KEY (`shelter_id`),
  ADD KEY `host_id` (`host_id`),
  ADD KEY `idx_shelter_host_id` (`host_id`),
  ADD KEY `idx_shelters_host_id` (`host_id`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `system_logs`
--
ALTER TABLE `system_logs`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_host_status` (`host_status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `alert_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `identity_verification`
--
ALTER TABLE `identity_verification`
  MODIFY `verification_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `occupants`
--
ALTER TABLE `occupants`
  MODIFY `occupant_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `shelter`
--
ALTER TABLE `shelter`
  MODIFY `shelter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `system_logs`
--
ALTER TABLE `system_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `identity_verification`
--
ALTER TABLE `identity_verification`
  ADD CONSTRAINT `identity_verification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `occupants`
--
ALTER TABLE `occupants`
  ADD CONSTRAINT `fk_occupants_request` FOREIGN KEY (`request_id`) REFERENCES `requests` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_occupants_shelter` FOREIGN KEY (`shelter_id`) REFERENCES `shelter` (`shelter_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_occupants_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `shelter`
--
ALTER TABLE `shelter`
  ADD CONSTRAINT `shelter_ibfk_1` FOREIGN KEY (`host_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

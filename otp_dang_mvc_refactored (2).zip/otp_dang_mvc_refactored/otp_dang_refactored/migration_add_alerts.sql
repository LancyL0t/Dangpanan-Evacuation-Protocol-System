-- ============================================================
-- DANGPANAN: Migration — Add alerts table
-- Run this once against your dangpanan_db database
-- ============================================================

CREATE TABLE IF NOT EXISTS `alerts` (
  `alert_id`      int(11) NOT NULL AUTO_INCREMENT,
  `type`          enum('critical','warning','info') NOT NULL DEFAULT 'info',
  `title`         varchar(200) NOT NULL,
  `body`          text NOT NULL,
  `source`        varchar(100) DEFAULT NULL,
  `affected_area` varchar(255) DEFAULT NULL,
  `is_active`     tinyint(1) NOT NULL DEFAULT 1,
  `created_at`    timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`alert_id`),
  KEY `idx_type` (`type`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed with sample alerts (optional — remove if you want to start empty)
INSERT INTO `alerts` (`type`, `title`, `body`, `source`, `affected_area`, `is_active`) VALUES
('critical', 'Typhoon Warning – Signal No. 3',
 'Typhoon Paeng is expected to make landfall within 18 hours. Residents in low-lying and flood-prone areas are strongly advised to evacuate immediately to the nearest evacuation center. Do not wait until the storm arrives.',
 'PAGASA', 'Tangub, Banago, Mandalagan, Singcang', 1),
('warning', 'Flash Flood Advisory',
 'Heavy continuous rainfall has been recorded upstream. Flash flooding is possible in riverside communities. Residents along the Lacson Street corridor and Barangay Handumanan are advised to be on alert.',
 'MDRRMO Bacolod', 'Handumanan, Lacson, Barangay 40', 1),
('info', '15 Evacuation Centers Now Open',
 'As of today, 15 evacuation centers across Bacolod City are now open and accepting evacuees. These include BAYS Center, USLS Coliseum, Panaad Stadium, and city schools. Bring your go-bag, medications, and important documents.',
 'Bacolod City Government', 'City-Wide', 1);

-- Ensure system_logs table exists (should already be in DB)
CREATE TABLE IF NOT EXISTS `system_logs` (
  `log_id`     int(11) NOT NULL AUTO_INCREMENT,
  `user_id`    int(11) DEFAULT NULL,
  `action`     varchar(255) NOT NULL,
  `details`    text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
